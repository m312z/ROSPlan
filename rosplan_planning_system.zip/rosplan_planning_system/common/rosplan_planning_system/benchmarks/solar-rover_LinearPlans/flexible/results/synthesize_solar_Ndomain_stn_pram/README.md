PyRobustEnvelope
================

A pure-python PDDL+ robust envelope synthesizer

Dependencies
------------
* python 3.x (tested on 3.5.2)
* pypddlplus
* pysmt
