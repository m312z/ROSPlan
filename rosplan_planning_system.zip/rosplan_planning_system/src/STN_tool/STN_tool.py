#!/usr/bin/env python3

import rospy
import rospkg

from std_msgs.msg import String
from std_srvs.srv import Empty
from rosplan_planning_system import main

class RobustEnvelope(object):
    '''
    todo
    '''
    def __init__(self):
        rospy.loginfo('Starting robust envelope node')
        # publications
        # self.pub_leds = rospy.Publisher('/todo', UInt8MultiArray, queue_size=10) # template stuff, TODO: fill
        # setup paths
        rospack = rospkg.RosPack()
        # get path of pkg
        pkg_path = rospack.get_path('rosplan_planning_system')
        self.data_path = pkg_path + '/common/bin/';
        self.domain_path = self.data_path + 'domain.pddl';
        self.problem_path = self.data_path + 'problem.pddl';
        self.plan_path = self.data_path + 'plan.pddl';
        # subscriptions
        rospy.Subscriber('rosplan_planner_interface/planner_output', String, self.planCallback, queue_size=1)
        rospy.Subscriber('rosplan_problem_interface/problem_instance', String, self.problemCallback, queue_size=1)
        rospy.logdebug('Ready to compute robust envelopes')
        # service offered by this node
        rospy.Service('run_STN', Empty, self.serviceCB)

    def serviceCB(self, req):
        '''
        callback for the STN tool service
        '''
       
        
        # call STN python tool
        rospy.loginfo('Calling STN python tool')
        #time python3 main.py construct benchmarks/auv/domains/pandora_domain_strategic_for_validation.pddl benchmarks/auv/problems/mission_10_0_5.pddl benchmarks/auv/stns_params_with_values/stn_plan_mission_10_0_5_params -d -S monolithic  -s z3 -q msat_lw
        #res = compute_envelope_construct(self.domain_path, self.problem_path,self.plan_path
                               #,debug=debug, splitting=args.splitting,
                               #early_forall_elimination=args.early_elimination,
                               #compact_encoding=compact_encoding,
                               #solver=args.solver,
                               #qelim_name=args.qelim,
                               #epsilon=Fraction(args.epsilon),
                               #simplify_effects=simplify_effects,
                               #learn=not args.no_learning
                               #)
        rospy.loginfo('yessssssssssssssssss')

    def planCallback(self, msg):
        '''
        write msg.data to textfile
        '''
        file = open(self.plan_path,'w')
        file.write(msg.data)
        file.close()
        
    def problemCallback(self, msg):
        file = open(self.problem_path,'w')
        file.write(msg.data)
        file.close()

    def start_robust_envelope(self):
        # wait for user to press ctrl + c (prevent the node from dying)
        rospy.spin()
        #while not rospy.is_shutdown():
            #if self.emotion_received == True:
                ## lower flag
                #self.emotion_received = False
                ## update mouth emotion
                #self.mouth_emotion_update()
                ## update eyes emotion
                #self.eyes_emotion_update()
            #self.loop_rate.sleep()

if __name__ == '__main__':
    rospy.init_node('robust_envelope_node', anonymous=False)
    robust_envelope_node = RobustEnvelope()
    robust_envelope_node.start_robust_envelope()
